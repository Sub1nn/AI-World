import React from "react";
import TravelAssistant from "./components/TravelAssistant";

function App() {
  return <TravelAssistant />;
}

export default App;
